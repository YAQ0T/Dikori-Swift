//
//  DikoriSwiftTests.swift
//  DikoriSwiftTests
//
//  Created by Ahmad Salous on 21/10/2025.
//

import Testing

struct DikoriSwiftTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
